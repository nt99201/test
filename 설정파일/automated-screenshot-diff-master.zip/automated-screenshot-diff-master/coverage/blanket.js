require('blanket')({
  // Only files that match the pattern will be instrumented
  pattern: '/automated-screenshot-diff/lib/'
});